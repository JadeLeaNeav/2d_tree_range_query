#include "mynode.h"

MyNode::MyNode()
{
}

MyNode::MyNode(QPointF * e) {
    this->key = e;
    this->left = NULL;
    this->right = NULL;
}

QPointF * MyNode::getKey() {
    return this->key;
}
MyNode * MyNode::getLeft() {
    return this->left;
}
MyNode * MyNode::getRight() {
    return this->right;
}

MyNode ** MyNode::getLeftPointer() {
    return &this->left;
}

MyNode ** MyNode::getRightPointer() {
    return &this->right;
}
