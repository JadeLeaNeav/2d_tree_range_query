#ifndef MYPOINTSLIST_H
#define MYPOINTSLIST_H
#include <QFuture>
#include <QPointF>


class MyPointsList
{
public:
    MyPointsList();

    // add a point at the end of the list
    void addPoint(QPointF new_point);

    // return the k-th element of the list
    QPointF getPoint(int k);

    // return the number of points of the list
    int getPointsNumber();

    //mergeSortX()
    //mergeSortY()

private:
    // constante used to modifiy the size of the memory available for the array
    static const int FIRST_SIZE = 100;

    // array of points
    QPointF * tab;

    // size of the memory available
    int current_size;

    // number of points in the array
    int points_number;
};

#endif // MYPOINTSLIST_H
