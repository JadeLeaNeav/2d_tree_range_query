#ifndef MYNODE_H
#define MYNODE_H


#include <QFuture>


class MyNode
{
public:
    MyNode();
    MyNode(QPointF * e);
    QPointF * getKey();
    MyNode * getLeft();
    MyNode * getRight();
    MyNode ** getLeftPointer();
    MyNode ** getRightPointer();
private:
    MyNode *left;
    MyNode *right;
    QPointF * key;
};

#endif // MYNODE_H
