// Convexe Hülle
// (c) Georg Umlauf, 2015

#include "glwidget.h"
#include <QtGui>
#include <GL/glu.h>
#include "mainwindow.h"
#include <math.h>


GLWidget::GLWidget(QWidget *parent) : QGLWidget(parent)
{	
    this->pointsList = new MyPointsList();
    this->queryList = new MyPointsList();
    this->XY = NULL;
    this->tree = NULL;
    this->state = 1;
    this->query = 0;
}

GLWidget::~GLWidget()
{
}

void GLWidget::paintGL()
{
    // clear
    glClear(GL_COLOR_BUFFER_BIT);

    // Koordinatensystem
    glColor3f(0.5,0.5,0.5);
    glBegin(GL_LINES);
    glVertex2f(-1.0, 0.0);
    glVertex2f( 1.0, 0.0);
    glVertex2f( 0.0,-1.0);
    glVertex2f( 0.0, 1.0);
    glEnd();

	// Konvexe Hülle zeichnen
	// TODO: draw convex hull using glBegin(GL_LINE_STRIP); ... glEnd();



    int n1 = this->pointsList->getPointsNumber();
    if (n1 > 5) {
        this->printLine(this->tree, 0, -1, 1, -1, 1);
    }


    glPointSize(5);
    glBegin(GL_POINTS);
    glColor3f(0,1,1);


    for (int k = 0 ; k < n1 ; k++) {
        glVertex2f(this->pointsList->getPoint(k).x(), this->pointsList->getPoint(k).y());
    }
    glEnd();

    glBegin(GL_LINES);
    glColor3f(1, 1, 0);
    glVertex2f(this->leftQ, this->downQ);
    glVertex2f(this->leftQ, this->upQ);
    glVertex2f(this->rightQ, this->downQ);
    glVertex2f(this->rightQ, this->upQ);
    glVertex2f(this->leftQ, this->downQ);
    glVertex2f(this->rightQ, this->downQ);
    glVertex2f(this->leftQ, this->upQ);
    glVertex2f(this->rightQ, this->upQ);
    glEnd();

    glPointSize(5);
    glBegin(GL_POINTS);
    glColor3f(0.6, 0.1, 1);

    int n2 = this->queryList->getPointsNumber();
    for (int k = 0 ; k < n2 ; k++) {
        glVertex2f(this->queryList->getPoint(k).x(), this->queryList->getPoint(k).y());
    }
    glEnd();

}


void GLWidget::initializeGL()
{
    resizeGL(width(),height());
}

void GLWidget::resizeGL(int width, int height)
{
    aspectx=1.0;
    aspecty=1.0;
    if (width>height) aspectx = float(width) /height;
    else              aspecty = float(height)/ width;
    glViewport    (0,0,width,height);
    glMatrixMode  (GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D    (-aspectx,aspectx,-aspecty,aspecty);
    glMatrixMode  (GL_MODELVIEW);
    glLoadIdentity();
}

QPointF GLWidget::transformPosition(QPoint p)
{
    return QPointF( (2.0*p.x()/ width() - 1.0)*aspectx,
		           -(2.0*p.y()/height() - 1.0)*aspecty);
}

void GLWidget::keyPressEvent(QKeyEvent * event)
{
	switch (event->key()) {
	default:
		break;
	}
	update();
}

void GLWidget::mousePressEvent(QMouseEvent *event)
{
    QPointF posF = transformPosition(event->pos());
    if (this->state) {

        if (event->buttons() & Qt::LeftButton ) {
            this->pointsList->addPoint(posF);

            if (this->pointsList->getPointsNumber() > 5) {
                this->XY = new MyPartitions(this->pointsList);
                constructBalanced2DTree(0, this->pointsList->getPointsNumber() -1, &(this->tree), 0);
                doRangeQuery();
            }
        }
    } else {
        if (this->query) {
            this->p2Q = posF;
            this->getQuery();
            this->query = 0;
            if (this->pointsList->getPointsNumber() > 5) {
                this->XY = new MyPartitions(this->pointsList);
                constructBalanced2DTree(0, this->pointsList->getPointsNumber() -1, &(this->tree), 0);
                doRangeQuery();
            }
        } else {
            this->p1Q = posF;
            this->query = 1;
        }
    }
    update();
}


void GLWidget::radioButton1Clicked()
{
    this->state = 1;
    update();
}

void GLWidget::radioButton2Clicked()
{
    this->state = 0;
    update();
}

void GLWidget::constructBalanced2DTree(int left, int right, MyNode ** n, int dir) {
   if (left <= right) {
       int m = ceil((left + right) / 2);

       //vertical
       if (dir) {
           * n = new MyNode(this->XY->getPointY(m));
           XY->partitionX(left, right, m);
           //XY->print();
       } else {
           * n = new MyNode(this->XY->getPointX(m));
           XY->partitionY(left, right, m);
           //XY->print();
       }
//       MyNode **nl;
//       MyNode **nr;
//       nl = &(*n)->getLeft();
//       nl = new MyNode();
//       nr = (*n)->getRight();
//       nr = new MyNode();
       constructBalanced2DTree(left, m -1, (*n)->getLeftPointer(), !dir);
       constructBalanced2DTree(m +1, right, (*n)->getRightPointer(), !dir);
   }

}

void GLWidget::printLine(MyNode * n, int dir, float left, float right, float down, float up) {
    if (n != NULL) {
        if (dir) {
            glBegin(GL_LINES);
            glColor3f(0, 0, 1);
            float y = n->getKey()->y();
//            glVertex2f(-1.0, y);
//            glVertex2f( 1.0, y);
            glVertex2f(right, y);
            glVertex2f(left, y);
            glEnd();

            printLine(n->getLeft(), !dir, left, right, down, y);
            printLine(n->getRight(), !dir, left, right, y, up);
        } else {
            glBegin(GL_LINES);
            glColor3f(0, 0, 1);
            float x = n->getKey()->x();
//            glVertex2f(x, -1.0);
//            glVertex2f(x, 1.0);
            glVertex2f(x, down);
            glVertex2f(x, up);
            glEnd();

            printLine(n->getLeft(), !dir, left, x, down, up);
            printLine(n->getRight(), !dir, x, right, down, up);
        }
    }
}

void GLWidget::getQuery() {
    this->leftQ = this->p1Q.x() < this->p2Q.x() ? this->p1Q.x() : this->p2Q.x();
    this->rightQ = this->p1Q.x() > this->p2Q.x() ? this->p1Q.x() : this->p2Q.x();
    this->downQ = this->p1Q.y() < this->p2Q.y() ? this->p1Q.y() : this->p2Q.y();
    this->upQ = this->p1Q.y() > this->p2Q.y() ? this->p1Q.y() : this->p2Q.y();
}

void GLWidget::rangeSearch(MyNode * n, int dir, MyPointsList * list) {
    if (n != NULL) {
        float left, right, coord;
        QPointF * p = n->getKey();
        if (dir) {
            left = this->downQ;
            right = this->upQ;
            coord = p->y();
        } else {
            left = this->leftQ;
            right = this->rightQ;
            coord = p->x();
        }
        if (this->isInQuery(*p)) {
            list->addPoint(*p);
        }
        if (left < coord) {
            rangeSearch(n->getLeft(), !dir, list);
        }
        if (right > coord) {
            rangeSearch(n->getRight(), !dir, list);
        }
    }
}

int GLWidget::isInQuery(QPointF p) {
    int a = p.x() > this->leftQ;
    int b = p.x() < this->rightQ;
    int c = p.y() > this->downQ;
    int d = p.y() < this->upQ;
    return a && b && c && d;
}

void GLWidget::doRangeQuery() {
    MyPointsList * list = new MyPointsList;
    rangeSearch(this->tree, 0, list);
    this->queryList = list;


}
