#include "mypartitions.h"


MyPartitions::MyPartitions(MyPointsList * L)
{
    int n = L->getPointsNumber();

    // allocation of memory
    this->X = (QPointF * ) malloc(n * sizeof(QPointF));
    this->Y = (QPointF * ) malloc(n * sizeof(QPointF));
    this->indexesX = (int * ) malloc(n * sizeof(int));
    this->indexesY = (int * ) malloc(n * sizeof(int));


    this->size = n;

    for (int k = 0 ; k < n ; k++) {
        this->X[k] = L->getPoint(k);
        this->Y[k] = L->getPoint(k);
        this->indexesX[k] = k;
        this->indexesY[k] = k;


    }

    print();
    //mergesort
    this->mergeSortX();
    this->mergeSortY();



}

QPointF * MyPartitions::getPointX(int k)
{

    if ( (0 <= k) && (k < this->size)) {
        return &this->X[k];
    } else {
        perror("Index out of range");
        exit (1);
    }
}

QPointF * MyPartitions::getPointY(int k)
{
    if ( (0 <= k) && (k < this->size)) {
        return &this->Y[k];
    } else {
        perror("Index out of range");
        exit (1);
    }
}

void MyPartitions::partitionX(int start, int end, int median)
{

    qDebug() << "start x";

    QPointF * X1 = (QPointF * ) malloc((median - start) * sizeof(QPointF));
    QPointF * X2 = (QPointF * ) malloc((end - median) * sizeof(QPointF));
    int x1 = 0;
    int x2 = 0;
    int limitX1 = median - start;
    int limitX2 = end - median;
    QPointF m = this->Y[median];
    QPointF current;
    float ym = m.y();
    for (int k = start ; k <= end; k++ ) {
         current = this->X[k];
        if ( ! isEqualQPointF(current, m) ) {
            if (current.y() < ym) {



                    qDebug() << "x1 : " << x1;
                    qDebug() <<  m << " ; " << current;


                    X1[x1] = current;
                    x1++;

            } else {

                if (x2 == limitX2) {
                    qDebug() << "ici";
                }

                qDebug() << "x2 : " << x2;
                qDebug() <<  m << " ; " << current;

                X2[x2] = current;
                x2++;
            }
        }
    }

    for (int k = start ; k < median ; k++) {
        this->X[k] = X1[k - start];
    }

    for (int k = median +1 ; k <= end ; k++) {
        this->X[k] = X2[k - median -1];
    }


    free(X1);
    free(X2);
    //print();

}

void MyPartitions::partitionY(int start, int end, int median)
{
    qDebug() << "start y";

    QPointF * Y1 = (QPointF * ) malloc((median - start) * sizeof(QPointF));
    QPointF * Y2 = (QPointF * ) malloc((end - median) * sizeof(QPointF));
    int y1 = 0;
    int y2 = 0;
    int limitY1 = median - start;
    int limitY2 = end - median;
    QPointF m = this->X[median];
    QPointF current;
    float xm = m.x();
    for (int k = start ; k <= end; k++ ) {
        current = this->Y[k];
        if ( ! isEqualQPointF(current, m) ) {
            if (current.x() < xm) {



                    qDebug() << "y1 : " << y1;
                    qDebug() <<  m << " ; " << current;

                    Y1[y1] = current;
                    y1++;

            } else {

                if (y2 == limitY2) {
                    qDebug() << "ici";
                }

                qDebug() << "y2 : " << y2;
                qDebug() <<  m << " ; " << current;

                Y2[y2] = current;
                y2++;
            }
        }
    }

    for (int k = start ; k < median ; k++) {
        this->Y[k] = Y1[k - start];
    }

    for (int k = median +1 ; k <= end ; k++) {
        this->Y[k] = Y2[k - median -1];
    }


    free(Y1);
    free(Y2);
    //print();
}

void MyPartitions::mergeSortX() {
    int n = this->size;
    if (n > 1) {
        mergeSortIndexX(0, n - 1);
    }
}




void MyPartitions::mergeX(int start1, int start2, int end1, int end2) {
    int k1 = start1;
    int k2 = start2;
    int k = 0;
    int y;
    QPointF * new_tab = (QPointF *) malloc((end2 - start1 + 1) * sizeof(QPointF));
    while (k1 <= end1 || k2 <= end2 ) {

        // we already put all the elements of tab1
        if (k1 > end1) {
            new_tab[k] = this->X[k2];
            y = this->indexesX[k2];
            this->indexesY[y] = start1 + k;
            k2++;
            k++;


        // we already put all the elements of tab2
        } else if (k2 > end2) {
            new_tab[k] = this->X[k1];
            y = this->indexesX[k1];
            this->indexesY[y] = start1 + k;
            k1++;
            k++;

        // the next element of tab1 is smaller than the next element of tab2
        } else if (this->X[k1].x() < this->X[k2].x()) {
            new_tab[k] = this->X[k1];
            y = this->indexesX[k1];
            this->indexesY[y] = start1 + k;
            k1++;
            k++;

        // the next element of tab1 and the next element of tab2 have the same x
//        } else if (this->tab[k1].getPoint().x() < this->tab[k2].getPoint().x()) {

//            // choosing regarding to the event
//            // we suppose lines are not sharing more than one point

//            // we need to put the beginning of a line firt
//            if (this->tab[k1].getEvent() == EventName::FIRST) {
//                new_tab[k] = this->tab[k1];
//                k1++;
//                k++;
//            } else if (this->tab[k2].getEvent() == EventName::FIRST) {
//                new_tab[k] = this->tab[k2];
//                k2++;
//                k++;

//            // then a vertical line
//            } else if (this->tab[k1].getEvent() == EventName::VERTICAL) {
//                new_tab[k] = this->tab[k1];
//                k1++;
//                k++;
//            } else if (this->tab[k2].getEvent() == EventName::VERTICAL) {
//                new_tab[k] = this->tab[k2];
//                k2++;
//                k++;

//            // then impossible
//            } else {
//                new_tab[k] = this->tab[k1];
//                k1++;
//                k++;
//            }

        // the next element of tab2 is smaller than the next element of tab1
        }  else {
            new_tab[k] = this->X[k2];
            y = this->indexesX[k2];
            this->indexesY[y] = start1 + k;
            k2++;
            k++;
        }

    }
    for (int i = 0 ; i < k ; i++) {
        this->X[start1 + i] = new_tab[i];
    }

    free(new_tab);

}



void MyPartitions::mergeSortIndexX(int start, int end) {
    if (end != start) {
        int middle = (start + end) / 2;
        mergeSortIndexX(start, middle);
        mergeSortIndexX(middle +1, end);
        mergeX(start, middle +1, middle, end);
    }
}


void MyPartitions::mergeSortY() {
    int n = this->size;
    if (n > 1) {
        mergeSortIndexY(0, n - 1);
    }
}




void MyPartitions::mergeY(int start1, int start2, int end1, int end2) {
    int k1 = start1;
    int k2 = start2;
    int k = 0;
    int x;
    QPointF * new_tab = (QPointF *) malloc((end2 - start1 + 1) * sizeof(QPointF));
    while (k1 <= end1 || k2 <= end2 ) {

        // we already put all the elements of tab1
        if (k1 > end1) {
            new_tab[k] = this->Y[k2];
            x = this->indexesY[k2];
            this->indexesX[x] = start1 + k;
            k2++;
            k++;


        // we already put all the elements of tab2
        } else if (k2 > end2) {
            new_tab[k] = this->Y[k1];
            x = this->indexesY[k1];
            this->indexesX[x] = start1 + k;
            k1++;
            k++;

        // the next element of tab1 is smaller than the next element of tab2
        } else if (this->Y[k1].y() < this->Y[k2].y()) {
            new_tab[k] = this->Y[k1];
            x = this->indexesY[k1];
            this->indexesX[x] = start1 + k;
            k1++;
            k++;

        // the next element of tab1 and the next element of tab2 have the same x
//        } else if (this->tab[k1].getPoint().x() < this->tab[k2].getPoint().x()) {

//            // choosing regarding to the event
//            // we suppose lines are not sharing more than one point

//            // we need to put the beginning of a line firt
//            if (this->tab[k1].getEvent() == EventName::FIRST) {
//                new_tab[k] = this->tab[k1];
//                k1++;
//                k++;
//            } else if (this->tab[k2].getEvent() == EventName::FIRST) {
//                new_tab[k] = this->tab[k2];
//                k2++;
//                k++;

//            // then a vertical line
//            } else if (this->tab[k1].getEvent() == EventName::VERTICAL) {
//                new_tab[k] = this->tab[k1];
//                k1++;
//                k++;
//            } else if (this->tab[k2].getEvent() == EventName::VERTICAL) {
//                new_tab[k] = this->tab[k2];
//                k2++;
//                k++;

//            // then impossible
//            } else {
//                new_tab[k] = this->tab[k1];
//                k1++;
//                k++;
//            }

        // the next element of tab2 is smaller than the next element of tab1
        }  else {
            new_tab[k] = this->Y[k2];
            x = this->indexesY[k2];
            this->indexesX[x] = start1 + k;
            k2++;
            k++;
        }

    }
    for (int i = 0 ; i < k ; i++) {
        this->Y[start1 + i] = new_tab[i];
    }

    free(new_tab);

}



void MyPartitions::mergeSortIndexY(int start, int end) {
    if (end != start) {
        int middle = (start + end) / 2;
        mergeSortIndexY(start, middle);
        mergeSortIndexY(middle +1, end);
        mergeY(start, middle +1, middle, end);
    }
}

void MyPartitions::print() {
    qDebug() << "start";
    int n = this->size;
    for (int k = 0 ; k < n ; k++) {
        qDebug() << X[k];
    }
    for (int k = 0 ; k < n ; k++) {
        qDebug() << indexesX[k];
    }
    for (int k = 0 ; k < n ; k++) {
        qDebug() << Y[k];
    }
    for (int k = 0 ; k < n ; k++) {
        qDebug() << indexesY[k];
    }
}

int MyPartitions::isEqualQPointF(QPointF p1, QPointF p2) {
    float af = p1.x() - p2.x();
    int ai = (af < MyPartitions::EPSILON);
    float bf = p1.y() - p2.y();
    int bi = (bf < MyPartitions::EPSILON);
    int c = (ai && bi);

    return ( ( fabs(p1.x() - p2.x()) < MyPartitions::EPSILON) && ( fabs(p1.y() - p2.y()) < MyPartitions::EPSILON) );
}
