#ifndef MYPARTITIONS_H
#define MYPARTITIONS_H

#include <QPointF>
#include "mypointslist.h"


class MyPartitions
{
public:
    MyPartitions(MyPointsList * L);
    QPointF * getPointX(int k);
    QPointF * getPointY(int k);
    void partitionX(int start, int end, int median);
    void partitionY(int start, int end, int median);
    void print();
private:
    void mergeSortX();
    void mergeSortIndexX(int start, int end);
    void mergeX(int start1, int start2, int end1, int end2);
    void mergeSortY();
    void mergeSortIndexY(int start, int end);
    void mergeY(int start1, int start2, int end1, int end2);
    int isEqualQPointF(QPointF p1, QPointF p2);

    const float EPSILON = 0.0001;

    QPointF * X;
    QPointF * Y;
    int * indexesX;
    int * indexesY;
    int size;
};

#endif // MYPARTITIONS_H
