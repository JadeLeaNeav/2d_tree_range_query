#include "mypartitions.h"


MyPartitions::MyPartitions(MyPointsList * L)
{
    int n = L->getPointsNumber();

    // allocation of memory
    this->X = (QPointF * ) malloc(n * sizeof(QPointF));
    this->Y = (QPointF * ) malloc(n * sizeof(QPointF));
    this->indexesX = (int * ) malloc(n * sizeof(int));
    this->indexesY = (int * ) malloc(n * sizeof(int));


    this->size = n;

    for (int k = 0 ; k < n ; k++) {
        this->X[k] = L->getPoint(k);
        this->Y[k] = L->getPoint(k);
        this->indexesX[k] = k;
        this->indexesY[k] = k;


    }


    //mergesort
    this->mergeSortX();
    this->mergeSortY();
    print();
}

QPointF * MyPartitions::getPointX(int k)
{

    if ( (0 <= k) && (k < this->size)) {
        return &this->X[k];
    } else {
        perror("Index out of range");
        exit (1);
    }
}

QPointF * MyPartitions::getPointY(int k)
{
    if ( (0 <= k) && (k < this->size)) {
        return &this->Y[k];
    } else {
        perror("Index out of range");
        exit (1);
    }
}

void MyPartitions::partitionX(int start, int end, int median)
{
    QPointF * X = (QPointF * ) malloc((end - start +1) * sizeof(QPointF));
    int i0;
    int i1 = start;
    int i2 = median +1;
    for (int k = start ; k <= end ; k++) {
        if (k != median) {
            i0 = this->indexesX[k];
            if (i0 < median) {
                X[i1 -start] = this->X[k];
                this->indexesY[i0] = i1;
                i1++;
            } else if (i0 > median) {
                X[i2 -start] = this->X[k];
                this->indexesY[i0] = i2;
                i2++;
            }
        }
    }
    for (int k = 0 ; k < end -start +1 ; k++) {
        if (k +start != median) {
            this->X[k +start] = X[k];
        }
    }
    free(X);
    print();

}

void MyPartitions::partitionY(int start, int end, int median)
{
    QPointF * Y = (QPointF * ) malloc((end - start +1) * sizeof(QPointF));
    int i0;
    int i1 = start;
    int i2 = median +1;
    for (int k = start ; k <= end ; k++) {
        if (k != median) {
            i0 = this->indexesY[k];
            if (i0 < median) {
                Y[i1 -start] = this->Y[k];
                this->indexesX[i0] = i1;
                i1++;
            } else if (i0 > median) {
                Y[i2 -start] = this->Y[k];
                this->indexesX[i0] = i2;
                i2++;
            }
        }
    }
    for (int k = 0 ; k < end -start +1 ; k++) {
        if (k +start != median) {
            this->Y[k +start] = Y[k];
        }
    }
    free(Y);
    print();
}

void MyPartitions::mergeSortX() {
    int n = this->size;
    if (n > 1) {
        mergeSortIndexX(0, n - 1);
    }
}




void MyPartitions::mergeX(int start1, int start2, int end1, int end2) {
    int k1 = start1;
    int k2 = start2;
    int k = 0;
    int y;
    QPointF * new_tab = (QPointF *) malloc((end2 - start1 + 1) * sizeof(QPointF));
    while (k1 <= end1 || k2 <= end2 ) {

        // we already put all the elements of tab1
        if (k1 > end1) {
            new_tab[k] = this->X[k2];
            y = this->indexesX[k2];
            this->indexesY[y] = start1 + k;
            k2++;
            k++;


        // we already put all the elements of tab2
        } else if (k2 > end2) {
            new_tab[k] = this->X[k1];
            y = this->indexesX[k1];
            this->indexesY[y] = start1 + k;
            k1++;
            k++;

        // the next element of tab1 is smaller than the next element of tab2
        } else if (this->X[k1].x() < this->X[k2].x()) {
            new_tab[k] = this->X[k1];
            y = this->indexesX[k1];
            this->indexesY[y] = start1 + k;
            k1++;
            k++;

        // the next element of tab1 and the next element of tab2 have the same x
//        } else if (this->tab[k1].getPoint().x() < this->tab[k2].getPoint().x()) {

//            // choosing regarding to the event
//            // we suppose lines are not sharing more than one point

//            // we need to put the beginning of a line firt
//            if (this->tab[k1].getEvent() == EventName::FIRST) {
//                new_tab[k] = this->tab[k1];
//                k1++;
//                k++;
//            } else if (this->tab[k2].getEvent() == EventName::FIRST) {
//                new_tab[k] = this->tab[k2];
//                k2++;
//                k++;

//            // then a vertical line
//            } else if (this->tab[k1].getEvent() == EventName::VERTICAL) {
//                new_tab[k] = this->tab[k1];
//                k1++;
//                k++;
//            } else if (this->tab[k2].getEvent() == EventName::VERTICAL) {
//                new_tab[k] = this->tab[k2];
//                k2++;
//                k++;

//            // then impossible
//            } else {
//                new_tab[k] = this->tab[k1];
//                k1++;
//                k++;
//            }

        // the next element of tab2 is smaller than the next element of tab1
        }  else {
            new_tab[k] = this->X[k2];
            y = this->indexesX[k2];
            this->indexesY[y] = start1 + k;
            k2++;
            k++;
        }

    }
    for (int i = 0 ; i < k ; i++) {
        this->X[start1 + i] = new_tab[i];
    }

    free(new_tab);

}



void MyPartitions::mergeSortIndexX(int start, int end) {
    if (end != start) {
        int middle = (start + end) / 2;
        mergeSortIndexX(start, middle);
        mergeSortIndexX(middle +1, end);
        mergeX(start, middle +1, middle, end);
    }
}


void MyPartitions::mergeSortY() {
    int n = this->size;
    if (n > 1) {
        mergeSortIndexY(0, n - 1);
    }
}




void MyPartitions::mergeY(int start1, int start2, int end1, int end2) {
    int k1 = start1;
    int k2 = start2;
    int k = 0;
    int x;
    QPointF * new_tab = (QPointF *) malloc((end2 - start1 + 1) * sizeof(QPointF));
    while (k1 <= end1 || k2 <= end2 ) {

        // we already put all the elements of tab1
        if (k1 > end1) {
            new_tab[k] = this->Y[k2];
            x = this->indexesY[k2];
            this->indexesX[x] = start1 + k;
            k2++;
            k++;


        // we already put all the elements of tab2
        } else if (k2 > end2) {
            new_tab[k] = this->Y[k1];
            x = this->indexesY[k1];
            this->indexesX[x] = start1 + k;
            k1++;
            k++;

        // the next element of tab1 is smaller than the next element of tab2
        } else if (this->Y[k1].y() < this->Y[k2].y()) {
            new_tab[k] = this->Y[k1];
            x = this->indexesY[k1];
            this->indexesX[x] = start1 + k;
            k1++;
            k++;

        // the next element of tab1 and the next element of tab2 have the same x
//        } else if (this->tab[k1].getPoint().x() < this->tab[k2].getPoint().x()) {

//            // choosing regarding to the event
//            // we suppose lines are not sharing more than one point

//            // we need to put the beginning of a line firt
//            if (this->tab[k1].getEvent() == EventName::FIRST) {
//                new_tab[k] = this->tab[k1];
//                k1++;
//                k++;
//            } else if (this->tab[k2].getEvent() == EventName::FIRST) {
//                new_tab[k] = this->tab[k2];
//                k2++;
//                k++;

//            // then a vertical line
//            } else if (this->tab[k1].getEvent() == EventName::VERTICAL) {
//                new_tab[k] = this->tab[k1];
//                k1++;
//                k++;
//            } else if (this->tab[k2].getEvent() == EventName::VERTICAL) {
//                new_tab[k] = this->tab[k2];
//                k2++;
//                k++;

//            // then impossible
//            } else {
//                new_tab[k] = this->tab[k1];
//                k1++;
//                k++;
//            }

        // the next element of tab2 is smaller than the next element of tab1
        }  else {
            new_tab[k] = this->Y[k2];
            x = this->indexesY[k2];
            this->indexesX[x] = start1 + k;
            k2++;
            k++;
        }

    }
    for (int i = 0 ; i < k ; i++) {
        this->Y[start1 + i] = new_tab[i];
    }

    free(new_tab);

}



void MyPartitions::mergeSortIndexY(int start, int end) {
    if (end != start) {
        int middle = (start + end) / 2;
        mergeSortIndexY(start, middle);
        mergeSortIndexY(middle +1, end);
        mergeY(start, middle +1, middle, end);
    }
}

void MyPartitions::print() {
    qDebug() << "start";
    int n = this->size;
    for (int k = 0 ; k < n ; k++) {
        qDebug() << X[k];
    }
    for (int k = 0 ; k < n ; k++) {
        qDebug() << indexesX[k];
    }
    for (int k = 0 ; k < n ; k++) {
        qDebug() << Y[k];
    }
    for (int k = 0 ; k < n ; k++) {
        qDebug() << indexesY[k];
    }
}
