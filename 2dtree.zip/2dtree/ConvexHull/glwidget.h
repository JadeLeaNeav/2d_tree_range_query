// Convexe Hulle
// 
// Widget fur Interaktion und Kontrolle 
//
// (c) Georg Umlauf, 2014

#ifndef GLWIDGET_H
#define GLWIDGET_H

#include <QGLWidget>
#include <QFuture>
#include "mypointslist.h"
#include "mypartitions.h"
#include "mynode.h"


class GLWidget : public QGLWidget
{
    Q_OBJECT
public:
    GLWidget                  (QWidget *parent=0);
    ~GLWidget                 ();
signals: 
	void continueRequest      ();
public slots:
    void radioButton1Clicked  ();
    void radioButton2Clicked  ();
protected:
    void paintGL              ();
    void initializeGL         ();
    void resizeGL             (int width, int height);
    void keyPressEvent        (QKeyEvent   *event);
    void mousePressEvent      (QMouseEvent *event);
private:
    void constructBalanced2DTree(int left, int right, MyNode ** n, int dir);
    void printLine(MyNode * n, int dir, float left, float right, float down, float up);
    QPointF transformPosition (QPoint p);
	double  aspectx, aspecty;
    MyPointsList * pointsList;
    MyPointsList * queryList;
    MyPartitions * XY;
    MyNode * tree;
    void getQuery();
    void rangeSearch(MyNode * n, int dir, MyPointsList * list);
    int isInQuery(QPointF p);
    void doRangeQuery();

    // 0 = querie mode ; 1 = points mode
    int state;
     // 0 = first point ; 1 = second point
    int query;

   QPointF p1Q;
   QPointF p2Q;
   float leftQ;
   float rightQ;
   float downQ;
   float upQ;
};



#endif // GLWIDGET_H
